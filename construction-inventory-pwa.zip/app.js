// Jobsite Inventory PWA (vanilla JS + IndexedDB). Works offline.

// ----- PWA Install prompt handling -----
let deferredPrompt = null;
const btnInstall = document.getElementById('btnInstall');
window.addEventListener('beforeinstallprompt', (e) => {
  e.preventDefault();
  deferredPrompt = e;
  btnInstall.classList.remove('hidden');
});
btnInstall?.addEventListener('click', async () => {
  if (!deferredPrompt) return;
  deferredPrompt.prompt();
  await deferredPrompt.userChoice;
  deferredPrompt = null;
  btnInstall.classList.add('hidden');
});

// Register Service Worker
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('./service-worker.js').catch(console.error);
  });
}

// ----- IndexedDB helpers -----
const DB_NAME = 'jobsite-inventory-db';
const DB_VERSION = 1;
const STORES = ['materials', 'usage', 'pos'];

function openDB() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = (e) => {
      const db = req.result;
      if (!db.objectStoreNames.contains('materials')) {
        const os = db.createObjectStore('materials', { keyPath: 'id' });
        os.createIndex('name', 'name', { unique: false });
      }
      if (!db.objectStoreNames.contains('usage')) {
        db.createObjectStore('usage', { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains('pos')) {
        const os = db.createObjectStore('pos', { keyPath: 'id' });
        os.createIndex('status', 'status', { unique: false });
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

async function dbTxn(store, mode, fn) {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(store, mode);
    const os = tx.objectStore(store);
    const result = fn(os);
    tx.oncomplete = () => resolve(result);
    tx.onerror = () => reject(tx.error);
  });
}

const uid = () => Math.random().toString(36).slice(2) + Date.now().toString(36);

// ----- Business logic (mirrors your spreadsheet formulas) -----
function computeReorderPoint(m) {
  const LT = Number(m.leadTimeDays || 0);
  const AWU = Number(m.avgWeeklyUsage || 0);
  const SS = Number(m.safetyStock || 0);
  if (!(LT > 0 && AWU >= 0)) return '';
  return Math.ceil((AWU * (LT / 7)) + SS);
}
function computeReorderNeeded(m) {
  const RP = computeReorderPoint(m);
  if (RP === '') return '';
  const QOH = Number(m.qtyOnHand || 0);
  const QR = Number(m.qtyReserved || 0);
  const QO = Number(m.qtyOrderedOpen || 0);
  return ((QOH - QR + QO) <= RP) ? 'YES' : 'NO';
}
function computeSuggestedOrder(m) {
  const RP = computeReorderPoint(m);
  if (RP === '') return '';
  const QOH = Number(m.qtyOnHand || 0);
  const QR = Number(m.qtyReserved || 0);
  const AWU = Number(m.avgWeeklyUsage || 0);
  const val = Math.max(RP - (QOH - QR) + AWU, 0);
  return Math.ceil(val);
}

// ----- Seed data if empty -----
async function seedIfEmpty() {
  const all = await dbTxn('materials', 'readonly', os => os.getAll());
  if (all.length) return;
  const samples = [
    { id: uid(), name: '2x4 Lumber', unit: 'Piece', location: 'Yard', supplier: 'ABC Lumber', leadTimeDays: 7, avgWeeklyUsage: 300, safetyStock: 100, qtyOnHand: 2000, qtyReserved: 200, qtyOrderedOpen: 500, notes: '' },
    { id: uid(), name: 'Concrete Bag 80lb', unit: 'Bag', location: 'Site A', supplier: 'ReadyMix Co', leadTimeDays: 5, avgWeeklyUsage: 200, safetyStock: 50, qtyOnHand: 400, qtyReserved: 50, qtyOrderedOpen: 0, notes: '' },
    { id: uid(), name: 'Electrical Wire THHN 12ga (500ft)', unit: 'Spool', location: 'Warehouse', supplier: 'ElecSupply Inc.', leadTimeDays: 14, avgWeeklyUsage: 15, safetyStock: 5, qtyOnHand: 20, qtyReserved: 2, qtyOrderedOpen: 3, notes: '' },
    { id: uid(), name: 'Drywall 4x8', unit: 'Sheet', location: 'Site B', supplier: 'BuildMart', leadTimeDays: 10, avgWeeklyUsage: 250, safetyStock: 75, qtyOnHand: 600, qtyReserved: 60, qtyOrderedOpen: 100, notes: '' },
    { id: uid(), name: '#4 Rebar 20ft', unit: 'Bar', location: 'Yard', supplier: 'SteelWorks', leadTimeDays: 9, avgWeeklyUsage: 120, safetyStock: 40, qtyOnHand: 350, qtyReserved: 30, qtyOrderedOpen: 40, notes: '' },
  ];
  await Promise.all(samples.map(m => dbTxn('materials', 'readwrite', os => os.put({ ...m, createdAt: Date.now(), updatedAt: Date.now() }))));
}

// ----- Rendering -----
const views = ['inventoryView', 'usageView', 'poView', 'poArchiveView', 'settingsView'];
document.querySelectorAll('.tab').forEach(btn => {
  btn.addEventListener('click', () => {
    const view = btn.dataset.view;
    document.querySelectorAll('.tab').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    views.forEach(v => document.getElementById(v).classList.remove('active'));
    document.getElementById(view).classList.add('active');
    if (view === 'inventoryView') renderInventory();
    if (view === 'usageView') renderUsage();
    if (view === 'poView') renderPOs();
    if (view === 'poArchiveView') renderPOArchive();
  });
});

// Inventory list
async function renderInventory(filter = '') {
  const list = document.getElementById('inventoryList');
  const all = await dbTxn('materials', 'readonly', os => os.getAll());
  const rows = all
    .filter(m => m.name.toLowerCase().includes(filter.toLowerCase()))
    .sort((a, b) => a.name.localeCompare(b.name));

  list.innerHTML = rows.map(m => {
    const rp = computeReorderPoint(m);
    const rn = computeReorderNeeded(m);
    const soq = computeSuggestedOrder(m);
    let badgeClass = 'good', badgeText = 'OK';
    if (rn === 'YES') { badgeClass = 'danger'; badgeText = 'Reorder'; }
    else if (rn === 'NO' && rp !== '') { badgeClass = 'good'; badgeText = 'OK'; }
    else { badgeClass = 'warn'; badgeText = 'Set Params'; }
    return `
      <article class="card">
        <div class="card-header">
          <strong>${m.name}</strong>
          <span class="badge ${badgeClass}">${badgeText}</span>
        </div>
        <div class="row">
          <span class="pill">${m.unit || ''}</span>
          <span class="pill">On Hand: <b>${m.qtyOnHand || 0}</b></span>
          <span class="pill">Reserved: <b>${m.qtyReserved || 0}</b></span>
          <span class="pill">Ordered: <b>${m.qtyOrderedOpen || 0}</b></span>
        </div>
        <div class="row">
          <span class="pill">Lead: ${m.leadTimeDays || 0}d</span>
          <span class="pill">AWU: ${m.avgWeeklyUsage || 0}</span>
          <span class="pill">SS: ${m.safetyStock || 0}</span>
        </div>
        <div class="row">
          <span class="pill">Reorder Pt: <b>${rp === '' ? '-' : rp}</b></span>
          <span class="pill">Suggested: <b>${soq === '' ? '-' : soq}</b></span>
        </div>
        <div class="row">
          <button class="btn" data-action="edit" data-id="${m.id}">Edit</button>
          <button class="btn ghost" data-action="use" data-id="${m.id}">Log Usage</button>
          <button class="btn ghost" data-action="po" data-id="${m.id}">New PO</button>
          <button class="btn danger" data-action="delete" data-id="${m.id}">Delete</button>
        </div>
        <p class="muted">${m.location || ''} • ${m.supplier || ''}</p>
        ${m.notes ? `<p class="muted">${m.notes}</p>` : ''}
      </article>
    `;
  }).join('');

  list.querySelectorAll('button').forEach(btn => {
    const id = btn.dataset.id;
    const action = btn.dataset.action;
    btn.addEventListener('click', () => {
      if (action === 'edit') openMaterialDialog(id);
      if (action === 'delete') deleteMaterial(id);
      if (action === 'use') openUsageDialog(id);
      if (action === 'po') openPODialog(id);
    });
  });
}

// Usage list
async function renderUsage() {
  const list = document.getElementById('usageList');
  const all = await dbTxn('usage', 'readonly', os => os.getAll());
  const materials = await dbTxn('materials', 'readonly', os => os.getAll());
  const byId = Object.fromEntries(materials.map(m => [m.id, m]));
  all.sort((a, b) => (b.date || 0) - (a.date || 0));
  list.innerHTML = all.map(u => `
    <article class="card">
      <div class="card-header">
        <strong>${byId[u.materialId]?.name || '(deleted material)'}</strong>
        <span class="badge">${new Date(u.date || Date.now()).toLocaleDateString()}</span>
      </div>
      <div class="row">
        <span class="pill">${u.qtyUsed} ${u.unit || ''}</span>
        ${u.phase ? `<span class="pill">${u.phase}</span>` : ''}
        ${u.by ? `<span class="pill">By: ${u.by}</span>` : ''}
      </div>
      ${u.notes ? `<p class="muted">${u.notes}</p>` : ''}
    </article>
  `).join('');
}

// POs list
async function renderPOs() {
  const list = document.getElementById('poList');
  const all = await dbTxn('pos', 'readonly', os => os.getAll());
  const materials = await dbTxn('materials', 'readonly', os => os.getAll());
  const byId = Object.fromEntries(materials.map(m => [m.id, m]));
  const open = all.filter(p => (p.status || 'Open') === 'Open').sort((a,b) => (b.date||0)-(a.date||0));
  list.innerHTML = open.map(p => `
    <article class="card">
      <div class="card-header">
        <strong>${p.poNumber || '(PO)'}</strong>
        <span class="badge warn">${(p.status || 'Open')}</span>
      </div>
      <div class="row">
        <span class="pill">${byId[p.materialId]?.name || ''}</span>
        <span class="pill">${p.qtyOrdered} ${p.unit || ''}</span>
        ${p.eta ? `<span class="pill">ETA: ${new Date(p.eta).toLocaleDateString()}</span>` : ''}
      </div>
      <div class="row">
        <span class="pill">Supplier: ${p.supplier || ''}</span>
        <span class="pill">Issued: ${p.date ? new Date(p.date).toLocaleDateString() : '-'}</span>
        <span class="pill">Price: $${Number(p.price||0).toFixed(2)}</span>
      </div>
      ${p.notes ? `<p class="muted">${p.notes}</p>` : ''}
      <div class="row">
        <button class="btn" data-action="close" data-id="${p.id}">Mark Received (Close)</button>
        <button class="btn danger" data-action="delete" data-id="${p.id}">Delete</button>
      </div>
    </article>
  `).join('');
  list.querySelectorAll('button').forEach(btn => {
    const id = btn.dataset.id;
    const action = btn.dataset.action;
    btn.addEventListener('click', async () => {
      if (action === 'close') {
        const po = await dbTxn('pos', 'readonly', os => os.get(id));
        if (!po) return;
        // On close: add qty to On Hand, subtract from Ordered
        const mat = await dbTxn('materials', 'readonly', os => os.get(po.materialId));
        if (mat) {
          mat.qtyOnHand = Number(mat.qtyOnHand || 0) + Number(po.qtyOrdered || 0);
          mat.qtyOrderedOpen = Math.max(0, Number(mat.qtyOrderedOpen || 0) - Number(po.qtyOrdered || 0));
          mat.updatedAt = Date.now();
          await dbTxn('materials', 'readwrite', os => os.put(mat));
        }
        po.status = 'Closed';
        po.closedAt = Date.now();
        await dbTxn('pos', 'readwrite', os => os.put(po));
        renderPOs();
        renderInventory();
      }
      if (action === 'delete') {
        await dbTxn('pos', 'readwrite', os => os.delete(id));
        renderPOs();
      }
    });
  });
}

// PO Archive (Closed POs with date + price)
async function renderPOArchive() {
  const list = document.getElementById('poArchiveList');
  const all = await dbTxn('pos', 'readonly', os => os.getAll());
  const materials = await dbTxn('materials', 'readonly', os => os.getAll());
  const byId = Object.fromEntries(materials.map(m => [m.id, m]));
  const closed = all.filter(p => (p.status || 'Open') === 'Closed').sort((a,b) => (b.closedAt||b.date||0)-(a.closedAt||a.date||0));
  list.innerHTML = closed.map(p => `
    <article class="card">
      <div class="card-header">
        <strong>${p.poNumber || '(PO)'}</strong>
        <span class="badge">${(p.status || 'Closed')}</span>
      </div>
      <div class="row">
        <span class="pill">${byId[p.materialId]?.name || ''}</span>
        <span class="pill">${p.qtyOrdered} ${p.unit || ''}</span>
        <span class="pill">Issued: ${p.date ? new Date(p.date).toLocaleDateString() : '-'}</span>
        ${p.closedAt ? `<span class="pill">Closed: ${new Date(p.closedAt).toLocaleDateString()}</span>` : ''}
        <span class="pill">Price: $${Number(p.price||0).toFixed(2)}</span>
      </div>
      ${p.notes ? `<p class="muted">${p.notes}</p>` : ''}
    </article>
  `).join('');
}

// ----- Dialogs & CRUD -----
const dlgMaterial = document.getElementById('dlgMaterial');
const dlgUsage = document.getElementById('dlgUsage');
const dlgPO = document.getElementById('dlgPO');

document.getElementById('btnAddMaterial').addEventListener('click', () => openMaterialDialog());
document.getElementById('btnAddUsage').addEventListener('click', () => openUsageDialog());
document.getElementById('btnAddPO').addEventListener('click', () => openPODialog());

document.getElementById('invSearch').addEventListener('input', (e) => renderInventory(e.target.value));

function fillMaterialForm(m = {}) {
  document.getElementById('matId').value = m.id || '';
  document.getElementById('matName').value = m.name || '';
  document.getElementById('matUnit').value = m.unit || '';
  document.getElementById('matLocation').value = m.location || '';
  document.getElementById('matSupplier').value = m.supplier || '';
  document.getElementById('matLead').value = m.leadTimeDays || 0;
  document.getElementById('matAWU').value = m.avgWeeklyUsage || 0;
  document.getElementById('matSS').value = m.safetyStock || 0;
  document.getElementById('matQOH').value = m.qtyOnHand || 0;
  document.getElementById('matQR').value = m.qtyReserved || 0;
  document.getElementById('matQO').value = m.qtyOrderedOpen || 0;
  document.getElementById('matNotes').value = m.notes || '';
}

async function openMaterialDialog(id) {
  const m = id ? await dbTxn('materials', 'readonly', os => os.get(id)) : {};
  fillMaterialForm(m || {});
  document.getElementById('dlgMaterialTitle').textContent = id ? 'Edit Material' : 'Add Material';
  dlgMaterial.showModal();
}
document.getElementById('saveMaterial').addEventListener('click', async (e) => {
  e.preventDefault();
  const id = document.getElementById('matId').value || uid();
  const obj = {
    id,
    name: document.getElementById('matName').value.trim(),
    unit: document.getElementById('matUnit').value.trim(),
    location: document.getElementById('matLocation').value.trim(),
    supplier: document.getElementById('matSupplier').value.trim(),
    leadTimeDays: Number(document.getElementById('matLead').value || 0),
    avgWeeklyUsage: Number(document.getElementById('matAWU').value || 0),
    safetyStock: Number(document.getElementById('matSS').value || 0),
    qtyOnHand: Number(document.getElementById('matQOH').value || 0),
    qtyReserved: Number(document.getElementById('matQR').value || 0),
    qtyOrderedOpen: Number(document.getElementById('matQO').value || 0),
    notes: document.getElementById('matNotes').value || '',
    updatedAt: Date.now(),
  };
  if (!obj.name) return;
  const exists = await dbTxn('materials', 'readonly', os => os.get(id));
  if (exists && exists.createdAt) obj.createdAt = exists.createdAt;
  else obj.createdAt = Date.now();
  await dbTxn('materials', 'readwrite', os => os.put(obj));
  dlgMaterial.close();
  renderInventory();
  populateMaterialPickers();
});

async function deleteMaterial(id) {
  if (!confirm('Delete this material?')) return;
  await dbTxn('materials', 'readwrite', os => os.delete(id));
  renderInventory();
  populateMaterialPickers();
}

function fillUsageForm(defMatId = '') {
  document.getElementById('useDate').valueAsDate = new Date();
  document.getElementById('usePhase').value = '';
  document.getElementById('useMaterial').value = defMatId || '';
  document.getElementById('useUnit').value = '';
  document.getElementById('useQty').value = 0;
  document.getElementById('useBy').value = '';
  document.getElementById('useNotes').value = '';
}

async function openUsageDialog(defMatId) {
  populateMaterialPickers();
  fillUsageForm(defMatId);
  dlgUsage.showModal();
}
document.getElementById('saveUsage').addEventListener('click', async (e) => {
  e.preventDefault();
  const matId = document.getElementById('useMaterial').value;
  const qty = Number(document.getElementById('useQty').value || 0);
  if (!matId || qty <= 0) return;
  const obj = {
    id: uid(),
    date: new Date(document.getElementById('useDate').value || new Date()).getTime(),
    phase: document.getElementById('usePhase').value,
    materialId: matId,
    unit: document.getElementById('useUnit').value,
    qtyUsed: qty,
    by: document.getElementById('useBy').value,
    notes: document.getElementById('useNotes').value,
  };
  await dbTxn('usage', 'readwrite', os => os.put(obj));
  // Decrement on-hand
  const m = await dbTxn('materials', 'readonly', os => os.get(matId));
  if (m) {
    m.qtyOnHand = Math.max(0, Number(m.qtyOnHand || 0) - qty);
    m.updatedAt = Date.now();
    await dbTxn('materials', 'readwrite', os => os.put(m));
  }
  dlgUsage.close();
  renderUsage();
  renderInventory();
});

function fillPOForm(defMatId = '') {
  document.getElementById('poId').value = '';
  document.getElementById('poNumber').value = '';
  document.getElementById('poDate').valueAsDate = new Date();
  document.getElementById('poSupplier').value = '';
  document.getElementById('poMaterial').value = defMatId || '';
  document.getElementById('poUnit').value = '';
  document.getElementById('poQty').value = 0;
  document.getElementById('poEta').value = '';
  document.getElementById('poStatus').value = 'Open';
  document.getElementById('poPrice').value = 0;
  document.getElementById('poNotes').value = '';
}

async function openPODialog(defMatId) {
  populateMaterialPickers();
  fillPOForm(defMatId);
  dlgPO.showModal();
}

document.getElementById('savePO').addEventListener('click', async (e) => {
  e.preventDefault();
  const id = document.getElementById('poId').value || uid();
  const matId = document.getElementById('poMaterial').value;
  const qty = Number(document.getElementById('poQty').value || 0);
  if (!matId || qty <= 0) return;
  const obj = {
    id,
    poNumber: document.getElementById('poNumber').value,
    date: new Date(document.getElementById('poDate').value || new Date()).getTime(),
    supplier: document.getElementById('poSupplier').value,
    materialId: matId,
    unit: document.getElementById('poUnit').value,
    qtyOrdered: qty,
    eta: document.getElementById('poEta').value ? new Date(document.getElementById('poEta').value).getTime() : null,
    status: document.getElementById('poStatus').value || 'Open',
    price: Number(document.getElementById('poPrice').value || 0),
    notes: document.getElementById('poNotes').value,
  };
  await dbTxn('pos', 'readwrite', os => os.put(obj));
  // Increase "Qty Ordered (Open)" for that material
  const m = await dbTxn('materials', 'readonly', os => os.get(matId));
  if (m) {
    m.qtyOrderedOpen = Number(m.qtyOrderedOpen || 0) + qty;
    m.updatedAt = Date.now();
    await dbTxn('materials', 'readwrite', os => os.put(m));
  }
  dlgPO.close();
  renderPOs();
  renderInventory();
});

async function populateMaterialPickers() {
  const mats = await dbTxn('materials', 'readonly', os => os.getAll());
  const opts = mats.map(m => `<option value="${m.id}">${m.name}</option>`).join('');
  document.getElementById('useMaterial').innerHTML = `<option value="">Select material</option>${opts}`;
  document.getElementById('poMaterial').innerHTML = `<option value="">Select material</option>${opts}`;
}

// Export / Import
async function exportJSON() {
  const mats = await dbTxn('materials', 'readonly', os => os.getAll());
  const usage = await dbTxn('usage', 'readonly', os => os.getAll());
  const pos = await dbTxn('pos', 'readonly', os => os.getAll());
  const blob = new Blob([JSON.stringify({ materials: mats, usage, pos }, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = `inventory-export-${new Date().toISOString().slice(0,10)}.json`;
  a.click();
  URL.revokeObjectURL(url);
}

async function exportCSVInventory() {
  const mats = await dbTxn('materials', 'readonly', os => os.getAll());
  const headers = ["Material","Unit","Location","Supplier","Lead Time (days)","Avg Weekly Usage","Safety Stock","Qty On Hand","Qty Reserved","Qty Ordered (Open)","Reorder Point (auto)","Reorder Needed? (auto)","Suggested Order Qty (auto)","Notes"];
  const rows = mats.map(m => [
    m.name, m.unit||'', m.location||'', m.supplier||'',
    m.leadTimeDays||0, m.avgWeeklyUsage||0, m.safetyStock||0, m.qtyOnHand||0, m.qtyReserved||0, m.qtyOrderedOpen||0,
    computeReorderPoint(m) || '', computeReorderNeeded(m) || '', computeSuggestedOrder(m) || '',
    (m.notes||'').replace(/\n/g, ' ')
  ]);
  const csv = [headers, ...rows].map(r => r.map(x => `"${String(x).replace(/"/g,'""')}"`).join(',')).join('\n');
  const blob = new Blob([csv], { type: 'text/csv' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = `inventory-${new Date().toISOString().slice(0,10)}.csv`;
  a.click();
  URL.revokeObjectURL(url);
}

// Buttons
document.getElementById('btnExport').addEventListener('click', exportCSVInventory);
document.getElementById('btnExportUsage').addEventListener('click', exportJSON); // quick JSON export includes usage
document.getElementById('btnExportPO').addEventListener('click', exportJSON);
document.getElementById('btnExportPOArchive').addEventListener('click', exportJSON);
document.getElementById('btnImport').addEventListener('click', async () => {
  const input = document.createElement('input');
  input.type = 'file'; input.accept = 'application/json';
  input.onchange = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const text = await file.text();
    try {
      const data = JSON.parse(text);
      if (data.materials) await Promise.all(data.materials.map(m => dbTxn('materials','readwrite', os=>os.put(m))));
      if (data.usage) await Promise.all(data.usage.map(u => dbTxn('usage','readwrite', os=>os.put(u))));
      if (data.pos) await Promise.all(data.pos.map(p => dbTxn('pos','readwrite', os=>os.put(p))));
      alert('Import complete');
      renderInventory(); renderUsage(); renderPOs(); renderPOArchive();
      populateMaterialPickers();
    } catch (err) { alert('Import failed: ' + err.message); }
  };
  input.click();
});
document.getElementById('btnClear').addEventListener('click', async () => {
  if (!confirm('Clear ALL data? This cannot be undone.')) return;
  const db = await openDB();
  db.close();
  await new Promise(res => {
    const del = indexedDB.deleteDatabase(DB_NAME);
    del.onsuccess = res; del.onerror = res; del.onblocked = res;
  });
  alert('Data cleared');
  renderInventory(); renderUsage(); renderPOs(); renderPOArchive();
});

// Initialize
(async function init() {
  await seedIfEmpty();
  renderInventory();
  populateMaterialPickers();
})();
